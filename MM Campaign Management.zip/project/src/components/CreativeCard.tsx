import React from 'react';
import { TrendingUp, Repeat, ChevronDown, ChevronUp, Tag } from 'lucide-react';
import { CreativeStats } from '../types';

interface CreativeCardProps {
  creative: CreativeStats;
  rank: number;
  subids: string[];
  isExpanded: boolean;
  onToggleExpand: () => void;
}

export function CreativeCard({ creative, rank, subids, isExpanded, onToggleExpand }: CreativeCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <span className="inline-flex items-center justify-center w-6 h-6 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-medium rounded-full">
              #{rank}
            </span>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white truncate">
              {creative.creative}
            </h3>
          </div>
        </div>
        <button
          onClick={onToggleExpand}
          className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label="Toggle details"
        >
          {isExpanded ? (
            <ChevronUp className="h-4 w-4 text-gray-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-gray-500" />
          )}
        </button>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
            <Repeat className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Frequency</p>
            <p className="text-lg font-bold text-blue-600 dark:text-blue-400">
              {creative.frequency}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
            <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
          </div>
          <div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Revenue</p>
            <p className="text-lg font-bold text-green-600 dark:text-green-400">
              ${creative.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      </div>
      
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2 mb-3">
            <Tag className="h-4 w-4 text-gray-500" />
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Also included in SUBIDs:
            </h4>
          </div>
          <div className="flex flex-wrap gap-2">
            {subids.map((subid) => (
              <span
                key={subid}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
              >
                {subid}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}