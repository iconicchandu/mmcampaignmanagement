import React from 'react';
import { Moon, Sun, BarChart3 } from 'lucide-react';
import { useTheme } from '../hooks/useTheme';

export function Header() {
  const { isDark, toggleTheme } = useTheme();

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white-600 rounded-lg">
        <img src="https://image.s7.sfmc-content.com/lib/fe2a11717d640474741277/m/1/95bf3bb4-0633-4a8d-adc4-a45afc7ded13.png" width="40px" ></img>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                MM Campaign Management
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Campaign Analytics Dashboard
              </p>
            </div>
          </div>
          
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            aria-label="Toggle theme"
          >
            {isDark ? (
              <Sun className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            ) : (
              <Moon className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}