import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { SummaryStats } from './components/SummaryStats';
import { CampaignSelector } from './components/CampaignSelector';
import { CampaignCreatives } from './components/CampaignCreatives';
import { SubidSelector } from './components/SubidSelector';
import { TopCampaignCreative } from './components/TopCampaignCreative';
import { CreativeCard } from './components/CreativeCard';
import { Charts } from './components/Charts';
import { DataTable } from './components/DataTable';
import { useTheme } from './hooks/useTheme';
import { parseMultipleCSVs, getUniqueSubids, getUniqueCampaigns, getCreativeStats, getTopCampaignCreative, getCampaignCreatives, getCreativeSubids, searchCreatives } from './utils/csvUtils';
import { ProcessedData } from './types';

function App() {
  const [data, setData] = useState<ProcessedData[]>([]);
  const [selectedSubid, setSelectedSubid] = useState<string>('');
  const [selectedCampaign, setSelectedCampaign] = useState<string>('');
  const [expandedCreatives, setExpandedCreatives] = useState<Set<string>>(new Set());
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'overview' | 'table'>('overview');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const { isDark } = useTheme();

  const handleFileSelect = async (files: File[]) => {
    setIsProcessing(true);
    setError('');
    
    try {
      const parsedData = await parseMultipleCSVs(files);
      if (parsedData.length === 0) {
        throw new Error('No valid data found. Please ensure your CSV contains SUBID, Creative, and REV columns with valid data.');
      }
      setData(parsedData);
      setSelectedSubid('');
      setSelectedCampaign('');
      setExpandedCreatives(new Set());
      setSearchTerm('');
      setActiveTab('overview');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process file');
    } finally {
      setIsProcessing(false);
    }
  };

  const subids = useMemo(() => getUniqueSubids(data), [data]);
  const campaigns = useMemo(() => getUniqueCampaigns(data), [data]);
  
  const creativeStats = useMemo(() => {
    if (!selectedSubid) return [];
    return getCreativeStats(data, selectedSubid, selectedCampaign);
  }, [data, selectedSubid, selectedCampaign]);

  const selectedSubidRevenue = useMemo(() => {
    return creativeStats.reduce((sum, creative) => sum + creative.totalRevenue, 0);
  }, [creativeStats]);

  const topCampaignCreative = useMemo(() => {
    if (!selectedCampaign) return null;
    return getTopCampaignCreative(data, selectedCampaign);
  }, [data, selectedCampaign]);

  const searchResults = useMemo(() => {
    if (!searchTerm.trim()) return [];
    return searchCreatives(data, searchTerm);
  }, [data, searchTerm]);

  const campaignCreatives = useMemo(() => {
    if (!selectedCampaign) return [];
    return getCampaignCreatives(data, selectedCampaign);
  }, [data, selectedCampaign]);

  const summaryStats = useMemo(() => {
    const totalRevenue = data.reduce((sum, row) => sum + row.revenue, 0);
    const uniqueSubids = new Set(data.map(row => row.subid)).size;
    const uniqueCreatives = new Set(data.map(row => row.creative)).size;
    const uniqueCampaigns = new Set(data.map(row => row.campaign)).size;
    
    return {
      totalRecords: data.length,
      totalRevenue,
      uniqueSubids,
      uniqueCreatives,
      uniqueCampaigns
    };
  }, [data]);

  const toggleCreativeExpansion = (creative: string) => {
    setExpandedCreatives(prev => {
      const newSet = new Set(prev);
      if (newSet.has(creative)) {
        newSet.delete(creative);
      } else {
        newSet.add(creative);
      }
      return newSet;
    });
  };

  if (data.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        <Header />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
              Welcome to MM Campaign Management
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 mt-2">
              Upload your CSV report to get started with analytics
            </p>
          </div>
          <FileUpload
            onFileSelect={handleFileSelect}
            isProcessing={isProcessing}
            error={error}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SummaryStats stats={summaryStats} />
        
        <CampaignSelector
          campaigns={campaigns}
          selectedCampaign={selectedCampaign}
          onCampaignChange={setSelectedCampaign}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          searchResults={searchResults}
        />
        
        {selectedCampaign && (
          <CampaignCreatives
            campaignName={selectedCampaign}
            topCreative={topCampaignCreative}
            allCreatives={campaignCreatives}
          />
        )}
        
        <SubidSelector
          subids={subids}
          selectedSubid={selectedSubid}
          onSubidChange={setSelectedSubid}
          totalRevenue={selectedSubidRevenue}
        />

        {selectedSubid && (
          <>
            <div className="mb-6">
              <div className="border-b border-gray-200 dark:border-gray-700">
                <nav className="-mb-px flex space-x-8">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`py-2 px-1 border-b-2 font-medium text-sm ${
                      activeTab === 'overview'
                        ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                    }`}
                  >
                    Overview
                  </button>
                  <button
                    onClick={() => setActiveTab('table')}
                    className={`py-2 px-1 border-b-2 font-medium text-sm ${
                      activeTab === 'table'
                        ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                    }`}
                  >
                    Data Table
                  </button>
                </nav>
              </div>
            </div>

            {activeTab === 'overview' ? (
              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {creativeStats.map((creative, index) => (
                    <CreativeCard
                      key={creative.creative}
                      creative={creative}
                      rank={index + 1}
                      subids={getCreativeSubids(data, creative.creative)}
                      isExpanded={expandedCreatives.has(creative.creative)}
                      onToggleExpand={() => toggleCreativeExpansion(creative.creative)}
                    />
                  ))}
                </div>

                {creativeStats.length > 0 && (
                  <Charts creatives={creativeStats} isDark={isDark} />
                )}
              </div>
            ) : (
              <DataTable 
                data={data} 
                selectedSubid={selectedSubid} 
                selectedCampaign={selectedCampaign}
              />
            )}
          </>
        )}

        {!selectedSubid && (
          <div className="text-center py-12">
            <p className="text-lg text-gray-500 dark:text-gray-400">
              {selectedCampaign 
                ? "Select a SUBID above to view detailed analytics for the selected campaign"
                : "Select a campaign and SUBID above to view detailed analytics"
              }
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;