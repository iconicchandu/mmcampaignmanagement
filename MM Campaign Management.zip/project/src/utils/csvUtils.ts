import Papa from 'papaparse';
import { CSVRow, ProcessedData, CreativeStats } from '../types';

// Function to separate creative and subid from the SUBID column
function separateCreativeAndSubid(subidValue: string): { creative: string; subid: string; campaign: string } {
  // Split by underscore and find the last part that matches the subid pattern
  const parts = subidValue.split('_');
  
  // Known subid patterns
  const subidPatterns = ['P24', 'JSG20', 'JSG21', 'JSG22', 'JSG18', 'JSG30PM', 'JSG29', '24MC', 'JSG26'];
  
  // Find the last part that matches a known subid pattern
  let subidIndex = -1;
  for (let i = parts.length - 1; i >= 0; i--) {
    if (subidPatterns.includes(parts[i])) {
      subidIndex = i;
      break;
    }
  }
  
  if (subidIndex === -1) {
    // If no known pattern found, assume the last part is the subid
    subidIndex = parts.length - 1;
  }
  
  const creative = parts.slice(0, subidIndex).join('_');
  const subid = parts.slice(subidIndex).join('_');
  
  // Extract campaign (first part before first underscore)
  const campaign = parts[0] || '';
  
  return {
    creative: creative || subidValue, // fallback to original if creative is empty
    subid: subid || subidValue, // fallback to original if subid is empty
    campaign: campaign
  };
}

export function parseCSV(file: File): Promise<ProcessedData[]> {
  return new Promise((resolve, reject) => {
    Papa.parse<CSVRow>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const processedData = results.data
            .filter(row => row.SUBID && row.REV)
            .map(row => {
              const { creative, subid, campaign } = separateCreativeAndSubid(row.SUBID.trim());
              return {
                subid: subid,
                creative: creative,
                campaign: campaign,
                revenue: parseFloat(row.REV) || 0
              };
            })
            .filter(row => row.revenue > 0 && row.creative && row.subid && row.campaign);

          resolve(processedData);
        } catch (error) {
          reject(new Error('Failed to process CSV data'));
        }
      },
      error: (error) => {
        reject(new Error(`CSV parsing error: ${error.message}`));
      }
    });
  });
}

export function parseMultipleCSVs(files: File[]): Promise<ProcessedData[]> {
  return new Promise(async (resolve, reject) => {
    try {
      const allData: ProcessedData[] = [];
      
      for (const file of files) {
        const fileData = await parseCSV(file);
        allData.push(...fileData);
      }
      
      resolve(allData);
    } catch (error) {
      reject(error);
    }
  });
}

export function getUniqueSubids(data: ProcessedData[]): string[] {
  return [...new Set(data.map(row => row.subid))].sort();
}

export function getUniqueCampaigns(data: ProcessedData[]): string[] {
  return [...new Set(data.map(row => row.campaign))].sort();
}

export function getCreativeStats(data: ProcessedData[], selectedSubid: string, selectedCampaign?: string): CreativeStats[] {
  let filteredData = data.filter(row => row.subid === selectedSubid);
  
  if (selectedCampaign) {
    filteredData = filteredData.filter(row => row.campaign === selectedCampaign);
  }
  
  const creativeMap = new Map<string, { frequency: number; totalRevenue: number }>();

  filteredData.forEach(row => {
    const existing = creativeMap.get(row.creative);
    if (existing) {
      existing.frequency += 1;
      existing.totalRevenue += row.revenue;
    } else {
      creativeMap.set(row.creative, { frequency: 1, totalRevenue: row.revenue });
    }
  });

  return Array.from(creativeMap.entries())
    .map(([creative, stats]) => ({
      creative,
      frequency: stats.frequency,
      totalRevenue: stats.totalRevenue
    }))
    .sort((a, b) => b.frequency - a.frequency);
}

export function getCampaignCreatives(data: ProcessedData[], selectedCampaign: string): CreativeStats[] {
  const campaignData = data.filter(row => row.campaign === selectedCampaign);
  const creativeMap = new Map<string, { frequency: number; totalRevenue: number }>();

  campaignData.forEach(row => {
    const existing = creativeMap.get(row.creative);
    if (existing) {
      existing.frequency += 1;
      existing.totalRevenue += row.revenue;
    } else {
      creativeMap.set(row.creative, { frequency: 1, totalRevenue: row.revenue });
    }
  });

  return Array.from(creativeMap.entries())
    .map(([creative, stats]) => ({
      creative,
      frequency: stats.frequency,
      totalRevenue: stats.totalRevenue,
      subids: getCreativeSubids(data, creative)
    }))
    .sort((a, b) => b.frequency - a.frequency);
}

export function getTopCampaignCreative(data: ProcessedData[], selectedCampaign: string): CreativeStats | null {
  const campaignCreatives = getCampaignCreatives(data, selectedCampaign);
  return campaignCreatives.length > 0 ? campaignCreatives[0] : null;
}

export function searchCreatives(data: ProcessedData[], searchTerm: string): CreativeStats[] {
  if (!searchTerm.trim()) return [];
  
  const creativeMap = new Map<string, { frequency: number; totalRevenue: number }>();
  const searchLower = searchTerm.toLowerCase();
  
  // Filter data for creatives that match the search term
  const filteredData = data.filter(row => 
    row.creative.toLowerCase().includes(searchLower)
  );
  
  filteredData.forEach(row => {
    const existing = creativeMap.get(row.creative);
    if (existing) {
      existing.frequency += 1;
      existing.totalRevenue += row.revenue;
    } else {
      creativeMap.set(row.creative, { frequency: 1, totalRevenue: row.revenue });
    }
  });
  
  return Array.from(creativeMap.entries())
    .map(([creative, stats]) => ({
      creative,
      frequency: stats.frequency,
      totalRevenue: stats.totalRevenue,
      subids: getCreativeSubids(data, creative)
    }))
    .sort((a, b) => b.frequency - a.frequency);
}

export function getCreativeSubids(data: ProcessedData[], creativeName: string): string[] {
  const subids = data
    .filter(row => row.creative === creativeName)
    .map(row => row.subid);
  
  return [...new Set(subids)].sort();
}

export function downloadCSV(data: ProcessedData[], filename: string) {
  const csv = Papa.unparse(data.map(row => ({
    SUBID: row.subid,
    Campaign: row.campaign,
    Creative: row.creative,
    REV: row.revenue.toFixed(2)
  })));

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}