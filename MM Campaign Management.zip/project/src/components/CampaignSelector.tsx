import React from 'react';
import { ChevronDown, Target, Search } from 'lucide-react';
import { CreativeStats } from '../types';

interface CampaignSelectorProps {
  campaigns: string[];
  selectedCampaign: string;
  onCampaignChange: (campaign: string) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  searchResults: CreativeStats[];
}

export function CampaignSelector({ 
  campaigns, 
  selectedCampaign, 
  onCampaignChange, 
  searchTerm, 
  onSearchChange, 
  searchResults 
}: CampaignSelectorProps) {
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2 bg-orange-100 dark:bg-orange-900/20 rounded-lg">
            <Target className="h-5 w-5 text-orange-600 dark:text-orange-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Campaign Selection
          </h3>
        </div>
        
        <div className="flex-1">
          <label htmlFor="campaign-select" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Select Campaign
          </label>
          <div className="relative">
            <select
              id="campaign-select"
              value={selectedCampaign}
              onChange={(e) => onCampaignChange(e.target.value)}
              className="w-full sm:w-64 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent appearance-none"
            >
              <option value="">All Campaigns</option>
              {campaigns.map((campaign) => (
                <option key={campaign} value={campaign}>
                  {campaign}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Search Section */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
            <Search className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Search Creatives
          </h3>
        </div>
        
        <div className="relative">
          <input
            type="text"
            placeholder="Search for a creative..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 pl-10 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        </div>

        {/* Search Results */}
        {searchTerm && (
          <div className="mt-4">
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Search Results ({searchResults.length})
            </h4>
            {searchResults.length > 0 ? (
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {searchResults.map((creative, index) => (
                  <div key={`${creative.creative}-${index}`} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <h5 className="font-medium text-gray-900 dark:text-white mb-2">
                      {creative.creative}
                    </h5>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500 dark:text-gray-400">Frequency:</span>
                        <span className="ml-1 font-medium text-blue-600 dark:text-blue-400">
                          {creative.frequency}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500 dark:text-gray-400">Revenue:</span>
                        <span className="ml-1 font-medium text-green-600 dark:text-green-400">
                          ${creative.totalRevenue.toFixed(2)}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500 dark:text-gray-400">SUBIDs:</span>
                        <span className="ml-1 font-medium text-purple-600 dark:text-purple-400">
                          {creative.subids?.length || 0}
                        </span>
                      </div>
                    </div>
                    {creative.subids && creative.subids.length > 0 && (
                      <div className="mt-2">
                        <div className="flex flex-wrap gap-1">
                          {creative.subids.map((subid) => (
                            <span
                              key={subid}
                              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200"
                            >
                              {subid}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                No creatives found matching "{searchTerm}"
              </p>
            )}
          </div>
        )}
        </div>
    </div>
  );
}