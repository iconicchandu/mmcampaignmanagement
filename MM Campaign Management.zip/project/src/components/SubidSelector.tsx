import React from 'react';
import { ChevronDown } from 'lucide-react';

interface SubidSelectorProps {
  subids: string[];
  selectedSubid: string;
  onSubidChange: (subid: string) => void;
  totalRevenue: number;
}

export function SubidSelector({ subids, selectedSubid, onSubidChange, totalRevenue }: SubidSelectorProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div className="flex-1">
          <label htmlFor="subid-select" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Select SUBID
          </label>
          <div className="relative">
            <select
              id="subid-select"
              value={selectedSubid}
              onChange={(e) => onSubidChange(e.target.value)}
              className="w-full sm:w-64 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
            >
              <option value="">Choose a SUBID...</option>
              {subids.map((subid) => (
                <option key={subid} value={subid}>
                  {subid}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
        
        {selectedSubid && (
          <div className="text-center sm:text-right">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Revenue for {selectedSubid}</p>
            <p className="text-2xl font-bold text-green-600 dark:text-green-400">
              ${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}