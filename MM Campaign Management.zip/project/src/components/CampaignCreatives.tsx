import React, { useState } from 'react';
import { Trophy, TrendingUp, Repeat, ChevronDown, ChevronUp, Tag } from 'lucide-react';
import { CreativeStats } from '../types';

interface CampaignCreativesProps {
  campaignName: string;
  topCreative: CreativeStats | null;
  allCreatives: CreativeStats[];
}

export function CampaignCreatives({ campaignName, topCreative, allCreatives }: CampaignCreativesProps) {
  const [expandedCreatives, setExpandedCreatives] = useState<Set<string>>(new Set());

  const toggleCreativeExpansion = (creative: string) => {
    setExpandedCreatives(prev => {
      const newSet = new Set(prev);
      if (newSet.has(creative)) {
        newSet.delete(creative);
      } else {
        newSet.add(creative);
      }
      return newSet;
    });
  };

  if (!campaignName) return null;

  return (
    <div className="space-y-6">
      {/* Top Performing Creative */}
      {topCreative && (
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/10 dark:to-orange-900/10 rounded-lg p-6 shadow-sm border border-yellow-200 dark:border-yellow-800">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg">
              <Trophy className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Top Performing Creative - {campaignName}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Highest frequency creative in this campaign
              </p>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
            <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              {topCreative.creative}
            </h4>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                  <Repeat className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Frequency</p>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {topCreative.frequency}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
                  <TrendingUp className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Revenue</p>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    ${topCreative.totalRevenue.toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-100 dark:bg-purple-900/20 rounded-lg">
                  <Tag className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">SUBIDs</p>
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                    {topCreative.subids?.length || 0}
                  </p>
                </div>
              </div>
            </div>

            {topCreative.subids && topCreative.subids.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Included in SUBIDs:
                </h5>
                <div className="flex flex-wrap gap-2">
                  {topCreative.subids.map((subid) => (
                    <span
                      key={subid}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                    >
                      {subid}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* All Campaign Creatives */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          All Creatives in {campaignName} ({allCreatives.length})
        </h3>
        
        <div className="space-y-4">
          {allCreatives.map((creative, index) => (
            <div key={creative.creative} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className="inline-flex items-center justify-center w-6 h-6 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-medium rounded-full">
                      #{index + 1}
                    </span>
                    <h4 className="text-lg font-medium text-gray-900 dark:text-white">
                      {creative.creative}
                    </h4>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <span className="text-sm text-gray-500 dark:text-gray-400">Frequency:</span>
                      <span className="ml-2 text-lg font-bold text-blue-600 dark:text-blue-400">
                        {creative.frequency}
                      </span>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500 dark:text-gray-400">Revenue:</span>
                      <span className="ml-2 text-lg font-bold text-green-600 dark:text-green-400">
                        ${creative.totalRevenue.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500 dark:text-gray-400">SUBIDs:</span>
                      <span className="ml-2 text-lg font-bold text-purple-600 dark:text-purple-400">
                        {creative.subids?.length || 0}
                      </span>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => toggleCreativeExpansion(creative.creative)}
                  className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                  aria-label="Toggle details"
                >
                  {expandedCreatives.has(creative.creative) ? (
                    <ChevronUp className="h-4 w-4 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-gray-500" />
                  )}
                </button>
              </div>
              
              {expandedCreatives.has(creative.creative) && creative.subids && creative.subids.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                  <div className="flex items-center space-x-2 mb-3">
                    <Tag className="h-4 w-4 text-gray-500" />
                    <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Included in SUBIDs:
                    </h5>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {creative.subids.map((subid) => (
                      <span
                        key={subid}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200"
                      >
                        {subid}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}