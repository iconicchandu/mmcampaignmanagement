export interface CSVRow {
  SUBID: string;
  REV: string;
}

export interface ProcessedData {
  subid: string;
  creative: string;
  campaign: string;
  revenue: number;
}

export interface CreativeStats {
  creative: string;
  frequency: number;
  totalRevenue: number;
  subids?: string[];
}

export interface SummaryStats {
  totalRecords: number;
  totalRevenue: number;
  uniqueSubids: number;
  uniqueCreatives: number;
  uniqueCampaigns: number;
}