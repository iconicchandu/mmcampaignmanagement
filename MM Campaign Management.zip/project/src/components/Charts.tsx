import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { CreativeStats } from '../types';

interface ChartsProps {
  creatives: CreativeStats[];
  isDark: boolean;
}

export function Charts({ creatives, isDark }: ChartsProps) {
  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
    '#F97316', '#06B6D4', '#84CC16', '#EC4899', '#6366F1'
  ];

  const top10 = creatives.slice(0, 10);

  const barData = top10.map((item, index) => ({
    name: item.creative.length > 15 ? `${item.creative.substring(0, 15)}...` : item.creative,
    frequency: item.frequency,
    revenue: item.totalRevenue,
    fullName: item.creative
  }));

  const pieData = top10.map((item, index) => ({
    name: item.creative.length > 20 ? `${item.creative.substring(0, 20)}...` : item.creative,
    frequency: item.frequency,
    revenue: item.totalRevenue,
    value: item.frequency,
    fullName: item.creative
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg border border-gray-200 dark:border-gray-600">
          <p className="font-medium text-gray-900 dark:text-white">{data.fullName}</p>
          <p className="text-blue-600 dark:text-blue-400">
            Frequency: {data.frequency}
          </p>
          <p className="text-green-600 dark:text-green-400">
            Revenue: ${data.revenue?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
      );
    }
    return null;
  };

  const PieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      return (
        <div className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg border border-gray-200 dark:border-gray-600">
          <p className="font-medium text-gray-900 dark:text-white">{data.payload.fullName}</p>
          <p className="text-blue-600 dark:text-blue-400">
            Frequency: {data.value}
          </p>
          <p className="text-green-600 dark:text-green-400">
            Revenue: ${data.payload.revenue?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8">
      {/* Bar Chart */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Top 10 Creatives by Frequency
        </h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData} margin={{ top: 20, right: 30, left: 40, bottom: 60 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#374151' : '#E5E7EB'} />
              <XAxis
                dataKey="name"
                angle={-45}
                textAnchor="end"
                height={60}
                tick={{ fontSize: 12, fill: isDark ? '#9CA3AF' : '#6B7280' }}
                stroke={isDark ? '#6B7280' : '#9CA3AF'}
              />
              <YAxis
                tick={{ fontSize: 12, fill: isDark ? '#9CA3AF' : '#6B7280' }}
                stroke={isDark ? '#6B7280' : '#9CA3AF'}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="frequency" fill="#3B82F6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Pie Chart */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Frequency Distribution (Top 10)
        </h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={120}
                paddingAngle={2}
                dataKey="frequency"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip content={<PieTooltip />} />
              <Legend
                wrapperStyle={{ color: isDark ? '#E5E7EB' : '#374151' }}
                formatter={(value) => value.length > 25 ? `${value.substring(0, 25)}...` : value}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}