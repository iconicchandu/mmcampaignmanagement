import React from 'react';
import { Trophy, TrendingUp, Repeat } from 'lucide-react';
import { CreativeStats } from '../types';

interface TopCampaignCreativeProps {
  topCreative: CreativeStats | null;
  campaignName: string;
}

export function TopCampaignCreative({ topCreative, campaignName }: TopCampaignCreativeProps) {
  if (!topCreative) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/10 dark:to-orange-900/10 rounded-lg p-6 shadow-sm border border-yellow-200 dark:border-yellow-800 mb-6">
      <div className="flex items-center space-x-3 mb-4">
        <div className="p-2 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg">
          <Trophy className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Top Revenue Creative - {campaignName}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Highest performing creative in this campaign
          </p>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
        <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-4 truncate">
          {topCreative.creative}
        </h4>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
              <TrendingUp className="h-5 w-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Total Revenue</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                ${topCreative.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
              <Repeat className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Frequency</p>
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {topCreative.frequency}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}