import React from 'react';
import { TrendingUp, Users, Package, DollarSign } from 'lucide-react';
import { SummaryStats as SummaryStatsType } from '../types';

interface SummaryStatsProps {
  stats: SummaryStatsType;
}

export function SummaryStats({ stats }: SummaryStatsProps) {
  const statItems = [
    {
      title: 'Total Revenue',
      value: `$${stats.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: 'bg-green-500'
    },
    {
      title: 'Total Records',
      value: stats.totalRecords.toLocaleString(),
      icon: TrendingUp,
      color: 'bg-blue-500'
    },
    {
      title: 'Unique SUBIDs',
      value: stats.uniqueSubids.toLocaleString(),
      icon: Users,
      color: 'bg-purple-500'
    },
    {
      title: 'Unique Campaigns',
      value: stats.uniqueCampaigns.toLocaleString(),
      icon: Package,
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {statItems.map((item) => (
        <div key={item.title} className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className={`${item.color} p-3 rounded-lg`}>
              <item.icon className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                {item.title}
              </p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {item.value}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}